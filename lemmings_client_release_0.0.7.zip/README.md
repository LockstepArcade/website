# Installation

You will need a credentials.bin file in order to connect to the server.
(Ask me for one, if I didn't send you one already.)

Unzip the game release archive into its own directory directory.
(You should then have 'client.exe', 'entry.png', and some other files, all in the same directory.)

Copy your connection credential file ('credentials.bin') into the same directory.

You should now just be able to double click 'client.exe' to start the game client.

## Running in a sandbox

If you're worried about running random executables from the internet, and you have Windows 11 Pro, I recommend running the game client inside [Windows Sandbox](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/).

To run this way: make sure you have enabled Windows Sandbox as an optional Windows feature, start Windows Sandbox, move the game client directory into Windows Sandbox,
and the double click the client to run from there.

## Resolving installation problems

Sometimes Windows marks files downloaded from the internet as potentially unsafe.
If Windows blocks the download or you can't extract/run the game, you may need to unblock them as follows:

For the ZIP file:

    Right-click the downloaded zip file
    Select "Properties"
    At the bottom, check the box next to "Unblock"
    Click "Apply" then "OK"
    Now extract the zip file

If the .exe is blocked after extraction:

    Right-click the game executable
    Select "Properties"
    Check "Unblock" at the bottom
    Click "Apply" then "OK"

If Windows SmartScreen appears:

    Click "More info"
    Then click "Run anyway"

## Antiviruses

If you have an antivirus installed, you may need to add the game folder to your antivirus exceptions list.
(Please refer to the documentation for your antivirus for more details.)

# Navigating the lobby

When you start the client you will see a server overview, showing any game rooms which have been created, and players that are online.

Click on a game room to see details about the game settings on the right hand side.

You can then either join an existing room (if there is one), or create a new game room (by clicking the relevant button).

When in a game room, all players need to click to indicate they are ready, and then the host (player at the top of the players in room list) can start the game.

# Game objectives

Its a lemmings clone, and the goal is to get your lemmings from a start position to an exit location.

For some maps, play is all against all, and other maps have team assignments.
There are also some coop challenges that can be played single player or as part of a team.

When there are team assignments, this will be specified in the game details (shown on the right hand side when a game is clicked in the server overview page,
and in the details shown on the right of the game room page).

The team who got the most lemmings into their exit when the game time expires is the winner!

# Controls

Pan the view around by holding middle mouse and dragging.

Zoom in and out with the mouse wheel.

Choose an order to give by clicking on an order in the orders bar at the top of the screen and then click near a lemming to give the order.
The function keys can also be used to select the order.

You only have a limited supply of each order type, so take care!

Note that you can set a directional filter to apply to your order assignments, by holding the left or right arrow keys.
Also, orders won't apply to falling lemmings.
(Selection bars will show which lemming will get an order, as relevant, for the current mouse position.)

F11 toggles between full screen and windowed modes.

# Organising games

Most of the time (e.g. if you connect at some arbitrary random time) the lobby will likely be completely empty, apart from you, on connection.

Multiple clients can be started on a single machine, for testing purposes, by double clicking 'client.exe' again after the game has started.
One client can then be used to create a game room, and then you can join this game room with other clients, to see everything working.

It is also possible to play games with just one player (even on maps where this doesn't really make sense), to try out the various in game mechanics and just see the game running.


