# 0.0.5

- removes the (confusing) concept of game waiting lists and shuffling around through this on game exit (players now just come back to exactly the same place in the lobby when leaving game)
- fixes an issue with slot assignment that meant that two players could be assigned the same slot
- fixed the player count in the lobby
- added 'raise ground' order
- bridge order duration increased
- step height increased (from 2 to 4 pixels)
- added some delay to digging, for dig sideways, with actual digging triggered after this delay or when the lemming first gets blocked by something
- added upward dig
- added raise ground order
- added horizontal bridge
- adjusted texture scaling mode for world rendering to work better for pixel width stuff like bridges
- direction filter is now set by holding left and right arrow keys (with mouse cursor reflecting this)
- arrow keys no longer control camera movement (but WASD is still available for this)
- added sound feedback on order given
- increased selection distance
- falling lemmings (which won't take orders) are rendered in a darked colour
- 'rooms' are created and joined in the lobby (renamed from 'games')
- added ready check boxes
- player name limited to 30 chars

# 0.0.6

- game network and simulation continues in the background (to prevent the game freezing for other participants), if the user locks the application by holding left mouse on the window taskbar and dragging the window
- tweak to separate lemmings that end up on exactly the same pixel
- second map, and the possibility to select a map when creating a room in the lobby
- support for horizontal and/or vertical wrap around at world boundaries (optional, per map)
- lobby reworked significantly, in particular with it now clearer when you are in a game room
- it is now possible to abort a game and return to the lobby (good if you are losing and there is no way to catch up!)
- team info is shown with the game settings
- the results of the last game played are shown in each game room
- game desynch checks are now made automatically
- wrapped worlds are also rendered wrapped, with tiled rendering

# 0.0.7

- a bunch of tweaks and adjustments to lemming behaviours
- lobby reworked significantly, again
- player names are now tracked persistently on the server side
- added co-op map and a set of co-op challenges based on this map, with a highscore table
- average exit times are tracked, in addition to total number exited, and serves as a tie breaker for same number exited
- added the possibility to play ranked matches, with player ratings updated based on results (using Glicko2), and a player rankings page
- bug fixes
