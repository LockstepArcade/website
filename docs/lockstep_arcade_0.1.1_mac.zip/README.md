# Web resources

-The game website: https://locksteparcade.com/
-Change log:  https://locksteparcade.com/changelog
-Setup instructions: https://locksteparcade.com/setup
-Beta signup: https://locksteparcade.com/signup
-Information about getting started: https://locksteparcade.com/gettingstarted
-Downloads (for new releases): https://locksteparcade.com/downloads

# Installation

You will need a credentials.bin file in order to connect to the server.
(Ask me for one, or request one through the beta signup form, if I didn't send you one already.)

After installation, copy your connection credential file ('credentials.bin') into the game directory.
(This should be in the same directory as 'LockstepArcade' or 'LockstepArcade.exe'.)

## Running in a sandbox

If you're worried about running random executables from the internet, and you have Windows 11 Pro, I recommend running the game client inside [Windows Sandbox](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/).

To run this way: make sure you have enabled Windows Sandbox as an optional Windows feature, start Windows Sandbox, move the game client directory into Windows Sandbox,
and the double click the client to run from there.

## Resolving installation problems

Sometimes files downloaded from the internet are marked as potentially unsafe.

If the game refuses to run, check https://locksteparcade.com/setup for ways around this.

## Antiviruses

If you have an antivirus installed, you may need to add the game folder to your antivirus exceptions list.
(Please refer to the documentation for your antivirus for more details.)
